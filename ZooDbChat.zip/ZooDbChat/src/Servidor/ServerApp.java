package Servidor;

	import java.awt.Color;
import java.awt.event.ActionEvent;
	import java.awt.event.ActionListener;

import javax.swing.BorderFactory;
import javax.swing.JButton;
	import javax.swing.JFrame;
	import javax.swing.JLabel;
	import javax.swing.JOptionPane;
	import javax.swing.JPanel;
	import javax.swing.JScrollPane;
	import javax.swing.JTextArea;
	import javax.swing.JTextField;
	import javax.swing.ScrollPaneConstants;
	
	import java.io.BufferedInputStream;
	import java.io.DataInputStream;
	import java.io.DataOutputStream;
	import java.io.IOException;
	import java.net.ServerSocket;
	import java.net.Socket;

	import abstracto.Cuidadores;
	import abstracto.Veterinarios;


	public class ServerApp extends Thread implements ActionListener {

		//elementos de la IU
		private JFrame ventana;
		private JPanel vent;
		private JPanel trabajadores;
		private JPanel chat;
		private JButton op1;
		private JButton op2;
		private JButton op3;
		private JButton op4;
		private JButton op5;
		private JButton Leon;
		private JButton Jiraf;
		private JButton Lemu;
		private JButton Pand;
		private JButton Pinguin;
		private JButton back;
		private JLabel La1;
		private JLabel La2;
		private JTextArea J;
		private JTextArea chattxt;
		private JLabel chattxtl;
		private JScrollPane SP;
		private JTextField cuit;
		private JTextField vett;
		private JLabel cui;
		private JLabel vet;
		private JLabel anim;
		private JTextField ani;
		private JButton cs;
		private JLabel pc;
		private JLabel pv;
		private JFrame mp;
		private JLabel AS;
		//elementos ventana modificar y eliminar
		private JFrame Eliminar;private JButton elim;private JTextField elia;private JButton elib; private JLabel elic;
		private JFrame modificar; private JButton modif; private JTextField tpeso;private JTextField tedad;
		private JLabel lpeso;private JLabel ledad; private JButton modia; private JLabel modi;private JButton acep;
		private JTextField modic;
		private JLabel lid; private JTextField tid; private JLabel lsexo; private JTextField tsexo;
		private JLabel ltipo; private JTextField ttipo; 
		
		
		int ta;float sueldoc; float sueldov; int a1; int a2; int a3; int aa; String pagov; String pagoc;float f1;public int a;
		//Instancia Singleton
		DB db=DB.getInstances();
		
		//sockets 
		private Socket socket;
		private ServerSocket server;
		private DataInputStream in;
		private DataOutputStream out;
	
	
		public ServerApp(){
			
			//ventana principal y Paneles
			this.ventana=new JFrame("ZooLogico");
			this.ventana.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
			this.vent=new JPanel();this.ventana.add(vent);this.vent.setLayout(null);this.vent.setBackground(Color.lightGray);
			this.vent.setBounds(0, 0, 950,600);this.vent.setVisible(true);
			this.trabajadores=new JPanel();this.ventana.add(trabajadores);this.trabajadores.setLayout(null);
			this.trabajadores.setBounds(0, 0, 950,600);this.trabajadores.setVisible(false);
			this.chat=new JPanel();this.ventana.add(chat);this.chat.setLayout(null);
			this.chat.setBounds(0, 0, 950,600);this.chat.setVisible(false);
			this.chattxtl=new JLabel("Mensajes del cliente:");this.chattxtl.setBounds(200, 50, 200, 50);this.chattxtl.setVisible(false);
			this.chattxt=new JTextArea();this.chattxt.setBounds(200, 100,400, 200);this.chattxt.setVisible(false);this.chattxt.setBorder(BorderFactory.createLineBorder(Color.GREEN,1));
			this.La1=new JLabel("Bienvenido al portal del ZooLogico");
			this.La1.setBounds(380, 100, 500, 50);this.La1.setVisible(true);
			this.vent.add(La1);
			this.AS=new JLabel("Animales en la Base de Datos:");this.vent.add(AS);this.AS.setVisible(false);
			this.AS.setBounds(380, 100, 500, 50);
			
			//Botones de opcion del menu principal
			this.op1=new JButton("1.Ingresar Animales al sistema");
			this.op1.setBounds(300, 200, 350, 50);
			this.vent.add(op1);
			this.op1.addActionListener((ActionListener) this);
			
			this.op2=new JButton("2.Mostrar lista de animales del sistema");
			this.op2.setBounds(300, 250, 350, 50);
			this.vent.add(op2);
			this.op2.addActionListener((ActionListener) this);
			
			this.op3=new JButton("3.Calcular pago de trabajadores");
			this.op3.setBounds(300, 300, 350, 50);
			this.vent.add(op3);
			this.op3.addActionListener((ActionListener) this);
			
			this.op4=new JButton("5.Salir");
			this.op4.setBounds(300, 400, 350, 50);	
			this.vent.add(op4);
			this.op4.addActionListener((ActionListener) this);
			
			this.op5=new JButton("4.Chat");
			this.op5.setBounds(300, 350, 350, 50);	
			this.vent.add(op5);
			this.op5.addActionListener((ActionListener) this);
			
			//Botones del menu ingresar al sistema
			this.Leon=new JButton("Leon");this.Pinguin=new JButton("Pinguino");this.Jiraf=new JButton("Jirafa");this.Lemu=new JButton("Lemur");
			this.Pand=new JButton("Panda");
			
			//Elementos de la opcion mostrar(se le aniadio la opcion de editar y eliminar)
			this.J=new JTextArea();this.vent.add(J);this.J.setVisible(false); this.J.setEditable(false);this.J.setBounds(300, 100, 500, 500);
			this.SP=new JScrollPane(J); this.vent.add(SP);this.SP.setVerticalScrollBarPolicy(ScrollPaneConstants.VERTICAL_SCROLLBAR_ALWAYS);
			this.SP.setBounds(100, 150, 750, 275); this.SP.setVisible(false);
			this.Eliminar=new JFrame("Eliminar de la BD");this.Eliminar.setResizable(false);
			this.Eliminar.setBounds(300, 200, 500, 400);this.Eliminar.setVisible(false);this.Eliminar.setLayout(null);
			this.elim=new JButton("Eliminar de BD");this.vent.add(elim);this.elim.setVisible(false);this.elim.setBounds(300, 500, 150, 50);
			this.elia=new JTextField();this.Eliminar.add(elia);this.elia.setBounds(200, 150, 100, 50);
			this.elic=new JLabel("Ingrese el id del animal a eliminar:");this.Eliminar.add(elic);
			this.elic.setBounds(150,100, 400, 50);
			this.elib=new JButton("Aceptar");this.Eliminar.add(elib);this.elib.setBounds(200, 200, 100, 50);
			
			
			this.modificar=new JFrame("Modificar Animal");this.modificar.setResizable(false);this.modificar.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
			this.modificar.setBounds(300, 200, 500, 400);this.modificar.setVisible(false);this.modificar.setLayout(null);
			this.modif=new JButton("Modificar");this.vent.add(modif);this.modif.setVisible(false);this.modif.setBounds(450, 500, 150, 50);
			this.modic=new JTextField();this.modificar.add(modic);this.modic.setBounds(200, 150, 100, 50);
			this.tpeso=new JTextField();this.modificar.add(tpeso);this.tpeso.setBounds(100, 50, 100, 50);
			this.tedad=new JTextField();this.modificar.add(tedad);this.tedad.setBounds(100, 100, 100, 50);
			this.lpeso=new JLabel("Peso");this.modificar.add(lpeso);
			this.lpeso.setBounds(0, 50, 50, 50);
			this.modia=new JButton("Aplicar");this.modificar.add(modia);this.modia.setBounds(350, 200, 100, 50);
			this.modi=new JLabel("Ingrese el id del animal a modificar:");this.modificar.add(modi);
			this.modi.setBounds(150, 100, 300, 50);
			this.acep=new JButton("Aceptar");this.modificar.add(acep);this.acep.setBounds(200, 200, 100, 50);
			this.lid=new JLabel("Id");this.modificar.add(lid);this.lid.setVisible(false);this.lid.setBounds(0, 0, 50, 50);
			this.tid=new JTextField();this.modificar.add(tid);this.tid.setVisible(false);this.tid.setBounds(100, 0, 100, 50);
			this.ledad=new JLabel("Edad");this.modificar.add(ledad);this.ledad.setVisible(false);this.ledad.setBounds(0, 100, 50, 50);
			this.lsexo=new JLabel("Sexo");this.modificar.add(lsexo);this.lsexo.setVisible(false);this.lsexo.setBounds(0, 150, 50, 50);
			this.ltipo=new JLabel("Tipo"); this.modificar.add(ltipo);this.ltipo.setVisible(false);this.ltipo.setBounds(0, 200, 50, 50);
			this.tsexo=new JTextField();this.modificar.add(tsexo);this.tsexo.setVisible(false);this.tsexo.setBounds(100,150,100,50);
			this.ttipo=new JTextField();this.modificar.add(ttipo);this.ttipo.setVisible(false);this.ttipo.setBounds(100, 200, 100, 50);
			
			//Boton volver al menu principal y atributos del frame principal
			this.back=new JButton("Menu");this.back.setBounds(0, 0, 100, 50);this.vent.add(back);
			this.back.addActionListener((ActionListener) this);this.back.setVisible(true);
			this.ventana.setLayout(null);this.ventana.setResizable(false);
			this.ventana.setBounds(200, 100, 950,600);
			this.ventana.setVisible(true);
			
			//Vista de pago de trabajadores
			this.vet=new JLabel("Ingrese el sueldo del veterinario");this.trabajadores.add(vet); this.vet.setBounds(300,200,300,50);this.vet.setVisible(false);
			this.cui=new JLabel("Ingrese el sueldo del cuidador");this.trabajadores.add(cui);this.cui.setBounds(300, 100, 300, 50);this.cui.setVisible(false);
			this.vett=new JTextField();this.trabajadores.add(vett);this.vett.setBounds(550, 200, 100, 50);this.vett.setVisible(false);
			this.cuit=new JTextField();this.trabajadores.add(cuit);this.cuit.setBounds(550, 100, 100, 50);this.cuit.setVisible(false);
			this.anim=new JLabel("Animales atendidos por el vet:"); this.trabajadores.add(anim);this.anim.setBounds(300, 300, 300, 50);
			this.ani=new JTextField();this.trabajadores.add(ani); this.ani.setBounds(550, 300, 100, 50);
			this.cs=new JButton("Calcular"); this.trabajadores.add(cs); this.cs.setBounds(400, 400, 100, 50);this.cs.setVisible(false);
			this.mp=new JFrame("Sueldo"); this.mp.setLayout(null);this.mp.setBounds(300, 200, 500, 400);this.mp.setVisible(false);
			this.pc=new JLabel(""); this.mp.add(pc);this.pc.setBounds(50, 0, 400, 50);this.pc.setVisible(false);
			this.pv=new JLabel(""); this.mp.add(pv);this.pv.setBounds(50, 100, 400, 50);this.pv.setVisible(false);
		}


	//Acciones de los botones
		public void actionPerformed(ActionEvent e) {
			// TODO Auto-generated method stub
			//Boton para agregar animales
					if(e.getSource()==op1) {
						//Se colocan los botones invisibles para la vista del menu secundario
						this.op1.setVisible(false);	this.op2.setVisible(false);	this.op3.setVisible(false);	this.op4.setVisible(false);this.op5.setVisible(false);
						this.La1.setVisible(false); this.J.setVisible(false); this.vent.setVisible(true);
						//Opciones
						this.La2=new JLabel("Seleccione el tipo de animal:");this.La2.setBounds(370, 100, 300, 50);
						this.vent.add(La2);	this.La2.setVisible(true); this.vent.setVisible(true);
						
						//Boton Leon
						this.Leon.setVisible(true);this.vent.add(Leon); this.Leon.setBounds(300, 200, 300, 50);
						this.Leon.addActionListener(new ActionListener() {
							public void actionPerformed(ActionEvent e) {
								Ventana2 sv=new Ventana2(a);
								sv.panel.add(back);
								ventana.setContentPane(sv.getJPanel());
								back.setVisible(true);
							}
					});
						//Boton Pinguino
						this.Pinguin.setVisible(true);this.vent.add(Pinguin); this.Pinguin.setBounds(300, 250, 300, 50);
						this.Pinguin.addActionListener(new ActionListener() {
							public void actionPerformed(ActionEvent e) {
								Ventana3 sv=new Ventana3();
								sv.panel.add(back);
								ventana.setContentPane(sv.getJPanel());
								back.setVisible(true);
							}
					});
						//Boton Jirafa
						this.Jiraf.setVisible(true);this.vent.add(Jiraf); this.Jiraf.setBounds(300, 300, 300, 50);
						this.Jiraf.addActionListener(new ActionListener() {
							public void actionPerformed(ActionEvent e) {
								Ventana4 sv=new Ventana4();
								sv.panel.add(back);
								ventana.setContentPane(sv.getJPanel());
								back.setVisible(true);
							}
					});
						//Boton Lemur
						this.Lemu.setVisible(true);this.vent.add(Lemu); this.Lemu.setBounds(300, 350, 300, 50);
						this.Lemu.addActionListener(new ActionListener() {
							public void actionPerformed(ActionEvent e) {
								Ventana5 sv=new Ventana5();
								sv.panel.add(back);
								ventana.setContentPane(sv.getJPanel());
								back.setVisible(true);
							}
					});
						//Boton panda
						this.Pand.setVisible(true);this.vent.add(Pand); this.Pand.setBounds(300, 400, 300, 50);
						this.Pand.addActionListener(new ActionListener() {
							public void actionPerformed(ActionEvent e) {
								Ventana6 sv=new Ventana6();
								sv.panel.add(back);
								ventana.setContentPane(sv.getJPanel());
								back.setVisible(true);
							}
					});
						
					}else {}
					
					//boton mostrar
					if(e.getSource()==op2) {
						if(db.cantidad()>=1) {
						this.J.setText(db.mostrar());
						this.AS.setVisible(true);this.elim.setVisible(true);
						this.op1.setVisible(false);	this.op2.setVisible(false);	this.op3.setVisible(false);	this.op4.setVisible(false);this.op5.setVisible(false);
						this.La1.setVisible(false); this.J.setVisible(true);this.SP.setVisible(true);this.back.setVisible(true);
						this.modif.setVisible(true);
						}
						else {
							this.J.setText("No hay informacion de animales en la base de datos...\nPor favor ingrese animales en el sistema para poder ser mostrados...");
							this.AS.setVisible(true);this.elim.setVisible(false);
							this.op1.setVisible(false);	this.op2.setVisible(false);	this.op3.setVisible(false);	this.op4.setVisible(false);this.op5.setVisible(false);
							this.La1.setVisible(false); this.J.setVisible(true);this.SP.setVisible(true);this.back.setVisible(true);
							this.modif.setVisible(false);
						}//Boton eliminar
						this.elim.addActionListener(new ActionListener() {
							public void actionPerformed(ActionEvent e) {
								back.setVisible(true);
								Eliminar.setVisible(true);//boton aceptar eliminacion
								elib.addActionListener(new ActionListener() {
									public void actionPerformed(ActionEvent e) {
										String In=elia.getText();
										int I=Integer.parseInt(In);
										if(isNumeric(elia.getText()) && ((I<db.Id()) && I>0)){
											I=Integer.parseInt(In);
									db.borrar(I);elia.setText(null);JOptionPane.showMessageDialog(Eliminar, "Eliminado de la BD");
									Eliminar.dispose();
									if(db.cantidad()>=1) {
									J.setText(db.mostrar());
									}else {
									J.setText("No hay informacion de animales en la base de datos...\nPor favor ingrese animales en el sistema para poder ser mostrados...");
									modif.setVisible(false);elim.setVisible(false);
									}
										}else {
											JOptionPane.showMessageDialog(Eliminar, "Error en el id");elia.setText(null);
										}
									}
								});
							}
					});
						//boton modificar
						this.modif.addActionListener(new ActionListener() {
							public void actionPerformed(ActionEvent e) {
								modic.setText(null);modia.setVisible(false);modi.setVisible(true);
								back.setVisible(true);acep.setVisible(true);modic.setVisible(true);
								modificar.setVisible(true);lpeso.setVisible(false);
								tpeso.setVisible(false);tedad.setVisible(false);ledad.setVisible(false);
								lid.setVisible(false);tid.setVisible(false);lsexo.setVisible(false);tsexo.setVisible(false);
								ltipo.setVisible(false);ttipo.setVisible(false);
								//boton aceptar
								acep.addActionListener(new ActionListener() {
									public void actionPerformed(ActionEvent e) {
										String aa=modic.getText();a1=Integer.parseInt(aa);
										if(isNumeric(aa) && ((a1<db.Id()) && a1>0)) {						
										a1=Integer.parseInt(aa);
										modia.setVisible(true);
										String a[]=db.guardar(a1);
										tid.setText(a[0]);tid.setEditable(false);
										tpeso.setText(a[1]);
										tedad.setText(a[2]);
										tsexo.setText(a[3]);tsexo.setEditable(false);
										ttipo.setText(a[4]);ttipo.setEditable(false);
										
										modic.setVisible(false);acep.setVisible(false);modi.setVisible(false);
										lpeso.setVisible(true);tpeso.setVisible(true);tedad.setVisible(true);ledad.setVisible(true);
										lid.setVisible(true);tid.setVisible(true);lsexo.setVisible(true);tsexo.setVisible(true);
										ltipo.setVisible(true);ttipo.setVisible(true);modi.setVisible(false);
										//boton para hacer cambios
										modia.addActionListener(new ActionListener() {
											public void actionPerformed(ActionEvent e) {
												a[0]=tid.getText();
												a[1]=tpeso.getText();
												a[2]=tedad.getText();
												a[3]=tsexo.getText();
												a[4]=ttipo.getText();
												if(isNumeric1(tpeso.getText())&& isNumeric(tedad.getText())) {
												db.modificar(a);
												JOptionPane.showMessageDialog(modificar, "Modificado");modificar.dispose();
												J.setText(db.mostrar());
												}else {
													JOptionPane.showMessageDialog(modificar, "Error, datos de tipo erroneo");
												}
									}
											});}else {
												modic.setText(null);
												JOptionPane.showMessageDialog(modificar, "Id erroneo");
											}
									}
								});
							}
					});
					}//fin boton mostrar
					
					//boton pago trabajadores
					if(e.getSource()==op3) {
						ta=db.cantidad();this.ventana.setContentPane(trabajadores);this.trabajadores.setVisible(true);this.vent.setVisible(false);
						this.trabajadores.add(back);this.back.setVisible(true);this.cs.setVisible(true);
						this.vet.setVisible(true);this.vett.setVisible(true);this.cui.setVisible(true);this.cuit.setVisible(true);
						this.anim.setVisible(true);this.ani.setVisible(true);mp.setVisible(false);
						this.cs.addActionListener(new ActionListener() {
							public void actionPerformed(ActionEvent e) {						
								String veta=vett.getText(); String cuia=cuit.getText(); String ana=ani.getText();
								if(isNumeric1(cuia)==true) {
								sueldoc=Float.parseFloat(cuia);
								a1=1;
								}else {
									a1=0;
								}
								if(isNumeric2(veta)==true && isNumeric(ana)==true) {
								sueldov=Float.parseFloat(veta);
								a2=1;
								}else {
									a2=0;
								}
								if( isNumeric(ana)==true) {
									aa=Integer.parseInt(ana);
									a3=1;
								}
								else {
									a3=0;
								}
								if(a1==1 && a2==1 && a3==1) {
									Cuidadores cuidador=new Cuidadores(sueldoc, ta);Veterinarios veterinario=new Veterinarios(sueldov, ta, aa);
									veterinario.pago();cuidador.pago();
									pagoc=Float.toString(cuidador.pago());pagov=Float.toString(veterinario.pago());
					
									mp.setVisible(true);pv.setVisible(true);pv.setText("El sueldo del vet es:"+pagov+"$");
									pc.setVisible(true);pc.setText("El pago del cuidador es"+pagoc+"$");
									cuit.setText(null);vett.setText(null);ani.setText(null);
								}
								if (a1==0 || a2==0 || a3==0){
									JOptionPane.showMessageDialog(trabajadores,"Error, revise los datos");
										cuit.setText(null);vett.setText(null);ani.setText(null);
								}
								
							}
						});
					}//fin boton pago de trabajadores
					
					
					//Boton salir
					if(e.getSource()==op4) {
						ventana.dispose();db.dbClose();//se desconecta de la base de datos 
						System.exit(0);//termina la ejecucion del programa 
					}
					
					//boton chat
					if (e.getSource()==op5) {
						ventana.setContentPane(chat);this.chat.setVisible(true);this.chat.add(back);this.back.setVisible(true);
						this.chat.add(chattxt);this.chattxt.setVisible(true);this.chat.add(chattxtl);this.chattxtl.setVisible(true);
					}
					//Boton volver al menu principal
					if(e.getSource()==back) {
						
						this.ventana.setContentPane(vent);this.vent.setVisible(true);this.vent.add(back);
						this.back.setVisible(true);this.AS.setVisible(false);this.elim.setVisible(false);this.modif.setVisible(false);
						this.Pinguin.setVisible(false);	this.Pand.setVisible(false);this.Leon.setVisible(false);this.Jiraf.setVisible(false);this.Lemu.setVisible(false);
						this.op1.setVisible(true);	this.op2.setVisible(true);	this.op3.setVisible(true);	this.op4.setVisible(true);this.op5.setVisible(true);
						this.La1.setVisible(true);this.La2.setVisible(false);
						this.vet.setVisible(false);this.cui.setVisible(false); this.vett.setVisible(false);this.cuit.setVisible(false);
						this.ani.setVisible(false);this.anim.setVisible(false); this.cs.setVisible(false); this.mp.setVisible(false);
					}
					
					
				}
		
		//hilo para la conexion con el cliente 
		public void run() {
			try {
				server=new ServerSocket(8080);
				while(true) {
					//acepta la conexion de la app cliente
					socket=server.accept();
					in=new DataInputStream(socket.getInputStream());//entrada de datos 
					out=new DataOutputStream(socket.getOutputStream());//salida de datos
					chattxt.setText(in.readUTF());//coloca el comando en la ventana de chat de la app servidor
					String c=chattxt.getText();//comando obtenido
					//comando mostrar
					if(c.equalsIgnoreCase("mostrar")) {
						String mostrar=db.mostrar();
						out.writeUTF(mostrar);
					}
					//comando ayuda
					if(c.equalsIgnoreCase("ayuda")) {
						String help="Para mostrar los animales existentes en la BD, escriba 'mostrar'\n"
								+ "Para hacer busqueda por especie ingrese el nombre de la especie en singular o plural\n"
								+ "Ej: 'Leon' o 'Leones'\nPara mostrar las especies de animales del zoo escriba 'animales'\n"
								+ "Para hacer busqueda por id, ingrese el id Ej: '1'";
						out.writeUTF(help);
					}
					//comando mostrar especies
					if(c.equalsIgnoreCase("animales")) {
						String animales="Animales del Zoo: \n ->Leones \n->Jirafas \n->Pinguinos \n->Lemures \n->Pandas\n";
						out.writeUTF(animales);
					}
					//comando de busqueda por id
					if(isNumeric(c)) {
						int animal=Integer.parseInt(c);
						if(animal<=db.cantidad()&& animal>0) {
							String[] mostrar1=db.guardar(animal);
							String mostrar2="Id:"+mostrar1[0]+"---"+"Peso:"+mostrar1[1]+"kg---"+"Edad:"+mostrar1[2]+"anios---"+"Sexo:"+mostrar1[3]+"---"+"Especie:"+mostrar1[4];
							out.writeUTF(mostrar2);
							
						}
						else {
							//caso que no exista el id ingresado
							JOptionPane.showMessageDialog(null, "Id inexistente");
						}
					}
					//busqueda de animales por especie
					try {
					if(c.equalsIgnoreCase("leon")||c.equalsIgnoreCase("leones")) {
						String leon="Leon";
						String animal=db.mostrarLeon(leon);
						out.writeUTF(animal);
						
					}
					if(c.equalsIgnoreCase("jirafa")||c.equalsIgnoreCase("jirafas")) {
						String jirafa="Jirafa";
						String animal=db.mostrarJirafa(jirafa);
						out.writeUTF(animal);
					
					}
					if(c.equalsIgnoreCase("pinguino")||c.equalsIgnoreCase("pinguinos")) {
						String pinguino="Pinguino";
						String animal=db.mostrarPinguino(pinguino);
						out.writeUTF(animal);
						
					}
					if(c.equalsIgnoreCase("lemur")||c.equalsIgnoreCase("lemures")) {
						String lemur="Lemur";
						String animal=db.mostrarLemur(lemur);
						out.writeUTF(animal);
						
					}
					if(c.equalsIgnoreCase("panda")||c.equalsIgnoreCase("pandas")) {
						String panda="Panda";
						String animal=db.mostrarPanda(panda);
						out.writeUTF(animal);
					
					}
					}catch(IOException e) {
						JOptionPane.showMessageDialog(ventana, "Comando incorrecto");
					}
					
					in.close();
					out.close();
				}
			}catch(IOException e){
				JOptionPane.showMessageDialog(ventana, "Comando incorrecto");
			}
		}
	
		
		//verficacion de datos int y float con un metodo
		 public static boolean isNumeric(String ana) {

		        boolean resultado;

		        try {
		            Integer.parseInt(ana);
		            resultado = true;
		        } catch (NumberFormatException excepcion) {
		            resultado = false;
		        }

		        return resultado;
		    }

		 public static boolean isNumeric1(String cuia) {

		        boolean resultado;

		        try {
		           Float.parseFloat(cuia);
		            resultado = true;
		        } catch (NumberFormatException excepcion) {
		            resultado = false;
		        }

		        return resultado;
		    }
		 public static boolean isNumeric2(String veta) {

		        boolean resultado;

		        try {
		           Float.parseFloat(veta);
		            resultado = true;
		        } catch (NumberFormatException excepcion) {
		            resultado = false;
		        }

		        return resultado;
		    }



		}


