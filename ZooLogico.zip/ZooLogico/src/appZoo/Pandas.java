package appZoo;

public class Pandas extends Animal{

	public Pandas(float PesoAnimal, int EdadAnimal, String SexoAnimal) {
		super(PesoAnimal, EdadAnimal, SexoAnimal);
		// TODO Auto-generated constructor stub
	}

	@Override
	public String toString() { //metodo toString, para mostrar los datos del objeto 
		StringBuilder sb=new StringBuilder();
		sb.append("\nPeso del Panda:");
		sb.append(getPesoAnimal());
		sb.append("kg\n");
		sb.append("Edad del Panda:");
		sb.append(getEdadAnimal());
		sb.append("Anios\n");
		sb.append("Sexo del Panda:");
		sb.append(getSexoAnimal());
		sb.append("\n");
		return sb.toString();
	}
	public static void add(Pandas Pai) {
		// TODO Auto-generated method stub
		
	}
}
