package abstracto;


public abstract class PagoTrabajadores {
	private float sueldo;
	private int ca;
	
	public PagoTrabajadores(float sueldo, int ca) {
		// TODO Auto-generated constructor stub
		this.sueldo=sueldo;
		this.ca=ca;
	}


	public abstract void pago();


	public float getSueldo() {
		return sueldo;
	}


	public void setSueldo(float sueldo) {
		this.sueldo = sueldo;
	}


	public int getCa() {
		return ca;
	}


	public void setCa(int ca) {
		this.ca = ca;
	}

}