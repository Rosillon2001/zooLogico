package intGraf;

public class Lemures extends Animal{

	public Lemures(float PesoAnimal, int EdadAnimal, String SexoAnimal) {
		super(PesoAnimal, EdadAnimal, SexoAnimal);
		// TODO Auto-generated constructor stub
	}
	
	@Override
	public String toString() { //metodo toString, para mostrar los datos del objeto 
		StringBuilder sb=new StringBuilder();
		sb.append("\n Peso del Lemur:");
		sb.append(getPesoAnimal());
		sb.append("kg\n");
		sb.append("Edad del Lemur:");
		sb.append(getEdadAnimal());
		sb.append("Anios\n");
		sb.append("Sexo del Lemur:");
		sb.append(getSexoAnimal());
		sb.append("\n");
		return sb.toString();
	}
	public static void add(Lemures Lei) {
		// TODO Auto-generated method stub
		
	}

}
