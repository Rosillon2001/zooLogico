package abstracto;

//Al veterinario se les paga su sueldo, un bono de 0.3 por cada animal en el zoo y un adicional de 5$ por cada animal atendido

public class Veterinarios extends PagoTrabajadores{
	
	private int aa;

	public Veterinarios(float sueldo, int ca, int aa) {
		super(sueldo, ca);
		this.aa=aa;
	}

	@Override 
	public float pago() {
		double r=(float) (this.getSueldo()+(this.getCa()*0.3)+(5*this.aa));
		return (float) r;
	}
}
