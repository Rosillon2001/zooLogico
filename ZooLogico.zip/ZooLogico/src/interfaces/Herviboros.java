package interfaces;

public class Herviboros implements DarAlimento{

	@Override
	public void comer() {
		// TODO Auto-generated method stub
		System.out.println("Los herviboros comen las frutas y verduras dadas por los cuidadores");
	}

}
