package abstracto;

//A los cuidadores del zoo se les paga su sueldo mas un bono de 0.5 por la cantidad de animales existentes en el zoo
public class Cuidadores extends PagoTrabajadores{
	
	public Cuidadores(float sueldo, int ca) {
		super(sueldo, ca);
	}

	@Override
	public void pago() {
	System.out.println("El pago de los cuidadores es: " +(this.getSueldo()+(this.getCa()*0.5))+"$");
	}
}
