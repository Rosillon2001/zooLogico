package interfaces;

public class Carnivoros implements DarAlimento{

	@Override
	public void comer() {
		// TODO Auto-generated method stub
		System.out.println("Los carnivoros comen la jugosa carne");
	}

}
