package appZoo;
import java.util.Scanner;
import abstracto.Cuidadores;
import abstracto.Veterinarios;

import java.io.IOException;
import java.util.ArrayList;

public class Main {



	public static void main(String[] args) {
		// TODO Auto-generated method stub
		//Animales ya exitentes en el zoologico
		
		//Leones
		Leones L1=new Leones(0, 0, "");
		L1.setPesoAnimal((float) 124.5);
		L1.setEdadAnimal(3);
		L1.setSexoAnimal("Femenino");
		
		Leones L2=new Leones(0, 0, "");
		L2.setPesoAnimal((float) 122);
		L2.setEdadAnimal(3);
		L2.setSexoAnimal("Femenino");
		
		Leones L3=new Leones(0, 0, "");
		L3.setPesoAnimal((float) 190);
		L3.setEdadAnimal(4);
		L3.setSexoAnimal("Masculino");
		
		Leones L4=new Leones(0, 0, "");
		L4.setPesoAnimal((float) 196);
		L4.setEdadAnimal(2);
		L4.setSexoAnimal("Masculino");
		
		//Pinguinos
		Pinguinos P1=new Pinguinos(0,0,"");
		P1.setPesoAnimal((float)20);
		P1.setEdadAnimal(3);
		P1.setSexoAnimal("Masculino");
		
		Pinguinos P2=new Pinguinos(0,0,"");
		P2.setPesoAnimal((float)22);
		P2.setEdadAnimal(2);
		P2.setSexoAnimal("Masculino");
		
		Pinguinos P3=new Pinguinos(0,0,"");
		P3.setPesoAnimal((float)19);
		P3.setEdadAnimal(1);
		P3.setSexoAnimal("Masculino");
		
		Pinguinos P4=new Pinguinos(0,0,"");
		P4.setPesoAnimal((float)21);
		P4.setEdadAnimal(2);
		P4.setSexoAnimal("Masculino");
		
		//Jirafas
		Jirafas J1=new Jirafas(0,0,"");
		J1.setPesoAnimal((float)722.3);
		J1.setEdadAnimal(3);
		J1.setSexoAnimal("Masculino");
		
		Jirafas J2=new Jirafas(0,0,"");
		J2.setPesoAnimal((float)740);
		J2.setEdadAnimal(4);
		J2.setSexoAnimal("Femenino");
		
		//Pandas
		Pandas Pa1=new Pandas(0,0,"");
		Pa1.setPesoAnimal((float)100);
		Pa1.setEdadAnimal(5);
		Pa1.setSexoAnimal("Femenino");
		
		Pandas Pa2=new Pandas(0,0,"");
		Pa2.setPesoAnimal((float)123);
		Pa2.setEdadAnimal(6);
		Pa2.setSexoAnimal("Masculino");
		
		//Lemures
		Lemures Le1=new Lemures(0,0,"");
		Le1.setPesoAnimal((float)4.3);
		Le1.setEdadAnimal(1);
		Le1.setSexoAnimal("Masculino");
		
		Lemures Le2=new Lemures(0,0,"");
		Le2.setPesoAnimal((float)3);
		Le2.setEdadAnimal(2);
		Le2.setSexoAnimal("Masculino");
		
		Lemures Le3=new Lemures(0,0,"");
		Le3.setPesoAnimal((float)2.5);
		Le3.setEdadAnimal(3);
		Le3.setSexoAnimal("Masculino");
		
		ArrayList <Leones> LeonB = new ArrayList<Leones>();//Arraylist con los leones preexistentes en el zoo
		LeonB.add(0, L1);
		LeonB.add(1,L2);
		LeonB.add(2,L3);
		LeonB.add(3,L4);		
		
		ArrayList <Pinguinos> PinguiB = new ArrayList<Pinguinos>();//Arraylist con los pinguinos ya existentes en el zoo
		PinguiB.add(0,P1);
		PinguiB.add(1,P2);
		PinguiB.add(2,P3);
		PinguiB.add(3,P4);
		
		ArrayList <Jirafas> JiraB=new ArrayList<Jirafas>();//Arraylist con las jirafas ya existentes en el zoo
		JiraB.add(0,J1);
		JiraB.add(1,J2);
		
		ArrayList <Pandas>PandaB= new ArrayList<Pandas>();//Arraylist con los pandas ya existentes en el zoo
		PandaB.add(0, Pa1);
		PandaB.add(1, Pa2);
		
		ArrayList <Lemures>LemurB= new ArrayList<Lemures>();//Arraylist con los lemures ya existentes en el zoo
		LemurB.add(0, Le1);
		LemurB.add(1, Le2);
		LemurB.add(2, Le3);
		
		ArrayList <Leones> Leon = new ArrayList<Leones>();//Creacion de los Arraylist que almacenan los nuevos animales ingresados
		ArrayList <Pinguinos> Pingui = new ArrayList<Pinguinos>();
		ArrayList <Jirafas>Jira= new ArrayList<Jirafas>();
		ArrayList <Pandas>Panda= new ArrayList<Pandas>();
		ArrayList <Lemures>Lemur= new ArrayList<Lemures>();
	
			System.out.println("Bienvenido al portal del ZooLogico");
			System.out.println("A continuacion se presentara el menu de gestion...");
			int o;
	do {
		//Cantidad de animales en el sistema
		int ta=Leon.size()+LeonB.size()+Pingui.size()+PinguiB.size()+Jira.size()+JiraB.size()+Panda.size()+PandaB.size()+Lemur.size()+LemurB.size();
		
				System.out.println("Seleccione la operacion a realizar:");
				System.out.println("1.Ingresar Animales a la app \n 2.Mostrar lista de animales clasificados en carnivoros y herviboros \n 3.Calcular pago de trabajadores \n 4.Salir");
				Scanner scanner= new Scanner(System.in);
				o=scanner.nextInt();
				
		switch(o) {
			case 1:{
				int a;
				System.out.println("Ingrese el tipo de animal:");
				System.out.println("1.Leon\n2.Pinguino\n3.Jirafa\n4.Panda\n5.Lemur\n");
				a=scanner.nextInt();
				
				switch(a) {
					case 1:{ //Leones
						int i=0, n, e = 0, ls;
						float p=0;
						String s;
						do {//ciclo iterativo para el ingreso de leones
							System.out.println("Ingrese un Leon al sistema");
							System.out.println("Ingrese el peso del leon:");
							p=scanner.nextFloat();
							System.out.println("Ingrese la edad del leon:");
							e=scanner.nextInt();
							System.out.println("Ingrese el sexo del leon:");
							s=scanner.next();
							Leones Li=new Leones(p, e, s );
							Li.setPesoAnimal(p);
							Li.setEdadAnimal(e);
							Li.setSexoAnimal(s);
							Leon.add(i,Li);
							System.out.println();
							i++;
							ls=Leon.size();
							System.out.println("Desea ingresar otro leon al sistema? 1.Si, 2.No");
							n=scanner.nextInt();
						}while(n==1);//fin del ciclo iterativo
						//Mostrar los leones ingresados
						int j=0;
						System.out.println("Lista de Leones Ingresados al sistema");
						for (j=0; j<ls;j++) {
							System.out.println("Leon "+(j+1)+" ingresado: "+Leon.get(j));
						}
					}break;//Final case 1
					
					case 2:{ //Pinguinos
						int i=0, n, e = 0, ps;
						float p=0;
						String s;
						do {
							System.out.println("Ingrese un Pinguino al sistema");
							System.out.println("Ingrese el peso del pinguino:");
							p=scanner.nextFloat();
							System.out.println("Ingrese la edad del pinguino:");
							e=scanner.nextInt();
							System.out.println("Ingrese el sexo del pinguino:");
							s=scanner.next();
							Pinguinos Pi=new Pinguinos(p, e, s);
							Pi.setPesoAnimal(p);
							Pi.setEdadAnimal(e);
							Pi.setSexoAnimal(s);
							Pingui.add(i,Pi);
							System.out.println();
							i++;
							ps=Pingui.size(); 
							System.out.println("Desea ingresar otro pinguino al sistema? 1.Si, 2.No");
							n=scanner.nextInt();
						}while(n==1);
						int j=0;
						System.out.println("Lista de Pinguinos Ingresados al sistema");
						//Mostrar los pinguinos ingresados
						for (j=0; j<ps;j++) {
							System.out.println("Pinguino "+(j+1)+" ingresado: "+Pingui.get(j));
						}
					}break;//Final case 2
					
					case 3:{//Jirafas
						int i=0, n, e = 0, js;
						float p=0;
						String s;
						do {
							System.out.println("Ingrese una Jirafa al sistema");
							System.out.println("Ingrese el peso de la Jirafa:");
							p=scanner.nextFloat();
							System.out.println("Ingrese la edad de la Jirafa:");
							e=scanner.nextInt();
							System.out.println("Ingrese el sexo de la Jirafa:");
							s=scanner.next();
							Jirafas Ji=new Jirafas(p, e, s);
							Ji.setPesoAnimal(p);
							Ji.setEdadAnimal(e);
							Ji.setSexoAnimal(s);
							Jira.add(i,Ji);
							System.out.println();
							i++;
							js=Jira.size(); 
							System.out.println("Desea ingresar otra Jirafa al sistema? 1.Si, 2.No");
							n=scanner.nextInt();
						}while(n==1);
						int j=0;
						System.out.println("Lista de Jirafas Ingresadas al sistema");
						//Mostrar las jirafas
						for (j=0; j<js;j++) {
							System.out.println("Jirafa "+(j+1)+" ingresada: "+Jira.get(j));
						}						
					}break;
					
					case 4:{//Pandas
						int i=0, n, e = 0, pas;
						float p=0;
						String s;
						do {//ciclo iterativo para el ingreso de Pandas
							System.out.println("Ingrese un Panda al sistema");
							System.out.println("Ingrese el peso del Panda:");
							p=scanner.nextFloat();
							System.out.println("Ingrese la edad del Panda:");
							e=scanner.nextInt();
							System.out.println("Ingrese el sexo del Panda:");
							s=scanner.next();
							Pandas Pai=new Pandas(p, e, s );
							Pai.setPesoAnimal(p);
							Pai.setEdadAnimal(e);
							Pai.setSexoAnimal(s);
							Panda.add(i,Pai);
							System.out.println();
							i++;
							pas=Panda.size();
							System.out.println("Desea ingresar otro Panda al sistema? 1.Si, 2.No");
							n=scanner.nextInt();
						}while(n==1);//fin del ciclo iterativo
						//Mostrar los Pandas ingresados
						int j=0;
						System.out.println("Lista de Pandas Ingresados al sistema");
						for (j=0; j<pas;j++) {
							System.out.println("Panda "+(j+1)+" ingresado: "+Panda.get(j));
						}
					}break;
					
					case 5:{//Lemures
						int i=0, n, e = 0, les;
						float p=0;
						String s;
						do {//ciclo iterativo para el ingreso de Pandas
							System.out.println("Ingrese un Lemur al sistema");
							System.out.println("Ingrese el peso del Lemur:");
							p=scanner.nextFloat();
							System.out.println("Ingrese la edad del Lemur:");
							e=scanner.nextInt();
							System.out.println("Ingrese el sexo del Lemur:");
							s=scanner.next();
							Lemures Lei=new Lemures(p, e, s );
							Lei.setPesoAnimal(p);
							Lei.setEdadAnimal(e);
							Lei.setSexoAnimal(s);
							Lemur.add(i,Lei);
							System.out.println();
							i++;
							les=Lemur.size();
							System.out.println("Desea ingresar otro Lemur al sistema? 1.Si, 2.No");
							n=scanner.nextInt();
						}while(n==1);//fin del ciclo iterativo
						//Mostrar los Lemures ingresados
						int j=0;
						System.out.println("Lista de Lemures Ingresados al sistema");
						for (j=0; j<les;j++) {
							System.out.println("Lemur "+(j+1)+" ingresado: "+Lemur.get(j));
						}
					}break;
					
					default:{
						System.out.println("Opcion incorrecta");
						System.out.println("Presione enter para continuar...");
						try {
							System.in.read();
						} catch (IOException e) {
							// TODO Auto-generated catch block
							e.printStackTrace();
						}						
					}
				}//final switch menor de ingreso de animales
				
			}break;//Final case 1 del menu de opciones
			
			case 2:{//case 2 del menu de opciones, mostrar todos los animales, clasificando en herviboros y carnivoros
				System.out.println("Animales carnivoros:\n");
				System.out.println("Leones en el zoologico: \t");
				System.out.println(LeonB);
				System.out.println(Leon);
				System.out.println("Pinguinos en el zoologico: \t");
				System.out.println(Pingui);
				System.out.println(PinguiB);
				System.out.println("Animales herviboros:\n");
				System.out.println("Jirafas en el zoologico: \t");
				System.out.println(Jira);
				System.out.println(JiraB);
				System.out.println("Pandas en el zoologico: \t");
				System.out.println(Panda);
				System.out.println(PandaB);
				System.out.println("Lemures en el zoologico: \t");
				System.out.println(Lemur);
				System.out.println(LemurB);
			}break;//Final case 2 del menu de opciones
			
			case 3:{//case 3 del menu de opciones, calculo de pagos
				System.out.println("1.Calcular pago Cuidador \n 2.Calcular pago Veterinario \n 3.Calcular el pago de ambos trabajadores \n");
				int p=scanner.nextInt();
				
				switch(p) { //opciones de calculo de pagos
					case 1:{ //cuidador
						System.out.println("Ingrese el sueldo del cuidador:");
						float sueldo=scanner.nextFloat();
						Cuidadores cui=new Cuidadores(sueldo, ta);
						cui.pago();
					}break;
					
					case 2:{//veterinario
						System.out.println("Ingrese el sueldo del veterinario:");
						float sueldo=scanner.nextFloat();
						System.out.println("Ingrese el numero de animales atendidos por el veterinario:");
						int aa=scanner.nextInt();
						Veterinarios vet=new Veterinarios(sueldo, ta, aa);
						vet.pago();
					}break;
					
					case 3:{//cuidador y veterinario
						System.out.println("Ingrese el sueldo del cuidador:");
						float sueldoc=scanner.nextFloat();
						Cuidadores cui=new Cuidadores(sueldoc, ta);
						System.out.println("Ingrese el sueldo del veterinario:");
						float sueldov=scanner.nextFloat();
						System.out.println("Ingrese el numero de animales atendidos por el veterinario:");
						int aa=scanner.nextInt();
						Veterinarios vet=new Veterinarios(sueldov, ta, aa);
						cui.pago();
						System.out.print("y ");
						vet.pago();
					}break;
					
					default: {
						System.out.println("Opcion incorrecta");
						System.out.println("Presione enter para continuar...");
						try {
							System.in.read();
						} catch (IOException e) {
							// TODO Auto-generated catch block
							e.printStackTrace();
						}
					}
				} //fin del switch de opciones de calculo de pago
			}break; //fin del case 3 del menu de opciones
			
			case 4:{ //case 4 del menu
				System.out.println("Saliendo...");
			}break; //fin del case 4 del menu
			
			default:{ //se muestra al ingresar una opcion no predefinida en el menu
				System.out.println("Opcion incorrecta");
				System.out.println("Presione enter para continuar...");
				try {
					System.in.read();
				} catch (IOException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
			} //final default
		} //final switch mayor
		
	}while(o!=4);
}

}

