package appZoo;

public class Pinguinos extends Animal {

	public Pinguinos(float PesoAnimal, int EdadAnimal, String SexoAnimal) {
		super(PesoAnimal, EdadAnimal, SexoAnimal);
		// TODO Auto-generated constructor stub
	}

	@Override
	public String toString() { // metodo toString, para mostrar los datos del objeto
		StringBuilder sb = new StringBuilder();
		sb.append("\nPeso del Pinguino:");
		sb.append(getPesoAnimal());
		sb.append("kg\n");
		sb.append("Edad del Pinguino:");
		sb.append(getEdadAnimal());
		sb.append("Anios\n");
		sb.append("Sexo del Pinguino:");
		sb.append(getSexoAnimal());
		sb.append("\n");
		return sb.toString();
	}

	public static void add(Pinguinos Pi) {
		// TODO Auto-generated method stub

	}

}
