module ZooLogicoV2 {
	requires java.desktop;
}