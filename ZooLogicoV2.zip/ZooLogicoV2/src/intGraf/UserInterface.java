package intGraf;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.ArrayList;
import javax.swing.*;

import appZoo.Jirafas;
import appZoo.Lemures;
import appZoo.Leones;
import appZoo.Pandas;
import appZoo.Pinguinos;
import appZoo.Animal;
import abstracto.Cuidadores;
import abstracto.Veterinarios;


public class UserInterface implements ActionListener{
	
	//Atributos de la ventana del menu
	private JFrame ventana;
	private JPanel vent;
	private JPanel trabajadores;
	private JButton op1;
	private JButton op2;
	private JButton op3;
	private JButton op4;
	private JButton Leon;
	private JButton Jiraf;
	private JButton Lemu;
	private JButton Pand;
	private JButton Pinguin;
	private JButton back;
	private JLabel La1;
	private JLabel La2;
	private JTextArea J;
	private JScrollPane SP;
	private JTextField cuit;
	private JTextField vett;
	private JLabel cui;
	private JLabel vet;
	private JLabel anim;
	private JTextField ani;
	private JButton cs;
	private JLabel pc;
	private JLabel pv;
	private JFrame mp;
	
	int ta;float sueldoc; float sueldov; int a1; int a2; int a3; int aa; String pagov; String pagoc;

	
	ArrayList <Leones> LeonB = new ArrayList<Leones>();//Arraylist con los leones preexistentes en el zoo
	
	ArrayList <Pinguinos> PinguiB = new ArrayList<Pinguinos>();//Arraylist con los pinguinos ya existentes en el zoo
		
	ArrayList <Jirafas> JiraB=new ArrayList<Jirafas>();//Arraylist con las jirafas ya existentes en el zoo
	
	ArrayList <Pandas>PandaB= new ArrayList<Pandas>();//Arraylist con los pandas ya existentes en el zoo
	
	ArrayList <Lemures>LemurB= new ArrayList<Lemures>();//Arraylist con los lemures ya existentes en el zoo
	
	public ArrayList <Leones> LeonA = new ArrayList<Leones>();//Creacion de los Arraylist que almacenan los nuevos animales ingresados
	public ArrayList <Pinguinos> PinguiA = new ArrayList<Pinguinos>();
	public ArrayList <Jirafas>JiraA= new ArrayList<Jirafas>();
	public ArrayList <Pandas>PandaA= new ArrayList<Pandas>();
	public ArrayList <Lemures>LemurA= new ArrayList<Lemures>();
	
	ArrayList <ArrayList<Animal>>Animales=new ArrayList<>();

	
 	public UserInterface() {
 		//Se crean los arrayList con los animales predefinidos en el zoo
 		CrearArray();
 				
 		//Creacion de la ventanas y paneles
		this.ventana=new JFrame("ZooLogico");
		this.ventana.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		this.vent=new JPanel();this.ventana.add(vent);this.vent.setLayout(null);
		this.vent.setBounds(0, 0, 950,600);this.vent.setVisible(true);
		this.trabajadores=new JPanel();this.ventana.add(trabajadores);this.trabajadores.setLayout(null);
		this.trabajadores.setBounds(0, 0, 950,600);this.trabajadores.setVisible(false);
		this.La1=new JLabel("Bienvenido al portal del ZooLogico");
		this.La1.setBounds(380, 100, 500, 50);this.La1.setVisible(true);
		this.vent.add(La1);
		
		//Botones de opcion
		this.op1=new JButton("1.Ingresar Animales al sistema");
		this.op1.setBounds(300, 200, 350, 50);
		this.vent.add(op1);
		this.op1.addActionListener((ActionListener) this);
		
		this.op2=new JButton("2.Mostrar lista de animales del sistema");
		this.op2.setBounds(300, 250, 350, 50);
		this.vent.add(op2);
		this.op2.addActionListener((ActionListener) this);
		
		this.op3=new JButton("3.Calcular pago de trabajadores");
		this.op3.setBounds(300, 300, 350, 50);
		this.vent.add(op3);
		this.op3.addActionListener((ActionListener) this);
		
		this.op4=new JButton("4.Salir");
		this.op4.setBounds(300, 350, 350, 50);	
		this.vent.add(op4);
		this.op4.addActionListener((ActionListener) this);
		
		this.Leon=new JButton("Leon");this.Pinguin=new JButton("Pinguino");this.Jiraf=new JButton("Jirafa");this.Lemu=new JButton("Lemur");
		this.Pand=new JButton("Panda");
		
		this.back=new JButton("Volver");this.back.setBounds(0, 0, 100, 50);this.vent.add(back);
		this.back.addActionListener((ActionListener) this);this.back.setVisible(true);
		
		//Elementos para mostrar animales
		this.J=new JTextArea();this.vent.add(J);this.J.setVisible(false); this.J.setEditable(false);this.J.setBounds(300, 100, 200, 200);
		this.SP=new JScrollPane(J); this.vent.add(SP);this.SP.setVerticalScrollBarPolicy(ScrollPaneConstants.VERTICAL_SCROLLBAR_ALWAYS);
		this.SP.setBounds(350, 100, 200, 300); this.SP.setVisible(false);
		
		//Elementos del panel trabajadores
		this.vet=new JLabel("Ingrese el sueldo del veterinario");this.trabajadores.add(vet); this.vet.setBounds(300,200,300,50);this.vet.setVisible(false);
		this.cui=new JLabel("Ingrese el sueldo del cuidador");this.trabajadores.add(cui);this.cui.setBounds(300, 100, 300, 50);this.cui.setVisible(false);
		this.vett=new JTextField();this.trabajadores.add(vett);this.vett.setBounds(550, 200, 100, 50);this.vett.setVisible(false);
		this.cuit=new JTextField();this.trabajadores.add(cuit);this.cuit.setBounds(550, 100, 100, 50);this.cuit.setVisible(false);
		this.anim=new JLabel("Animales atendidos por el vet:"); this.trabajadores.add(anim);this.anim.setBounds(300, 300, 300, 50);
		this.ani=new JTextField();this.trabajadores.add(ani); this.ani.setBounds(550, 300, 100, 50);
		this.cs=new JButton("Calcular"); this.trabajadores.add(cs); this.cs.setBounds(400, 400, 100, 50);this.cs.setVisible(false);
		this.mp=new JFrame("Sueldo"); this.mp.setLayout(null);this.mp.setBounds(300, 200, 500, 400);this.mp.setVisible(false);
		this.pc=new JLabel(""); this.mp.add(pc);this.pc.setBounds(50, 0, 400, 50);this.pc.setVisible(false);
		this.pv=new JLabel(""); this.mp.add(pv);this.pv.setBounds(50, 100, 400, 50);this.pv.setVisible(false);
				
		//Atributos de la ventana principal
		this.ventana.setLayout(null);this.ventana.setResizable(false);
		this.ventana.setBounds(200, 100, 950,600);
		this.ventana.setVisible(true);
	}

 	public void CrearArray() {
 		//Animales ya exitentes en el zoologico
		
			//Leones
			Leones L1=new Leones(0, 0, "");
			L1.setPesoAnimal((float) 124.5);
			L1.setEdadAnimal(3);
			L1.setSexoAnimal("Femenino");
			
			Leones L2=new Leones(0, 0, "");
			L2.setPesoAnimal((float) 122);
			L2.setEdadAnimal(3);
			L2.setSexoAnimal("Femenino");
			
			Leones L3=new Leones(0, 0, "");
			L3.setPesoAnimal((float) 190);
			L3.setEdadAnimal(4);
			L3.setSexoAnimal("Masculino");
			
			Leones L4=new Leones(0, 0, "");
			L4.setPesoAnimal((float) 196);
			L4.setEdadAnimal(2);
			L4.setSexoAnimal("Masculino");
			
			//Pinguinos
			Pinguinos P1=new Pinguinos(0,0,"");
			P1.setPesoAnimal((float)20);
			P1.setEdadAnimal(3);
			P1.setSexoAnimal("Masculino");
			
			Pinguinos P2=new Pinguinos(0,0,"");
			P2.setPesoAnimal((float)22);
			P2.setEdadAnimal(2);
			P2.setSexoAnimal("Masculino");
			
			Pinguinos P3=new Pinguinos(0,0,"");
			P3.setPesoAnimal((float)19);
			P3.setEdadAnimal(1);
			P3.setSexoAnimal("Masculino");
			
			Pinguinos P4=new Pinguinos(0,0,"");
			P4.setPesoAnimal((float)21);
			P4.setEdadAnimal(2);
			P4.setSexoAnimal("Masculino");
			
			//Jirafas
			Jirafas J1=new Jirafas(0,0,"");
			J1.setPesoAnimal((float)722.3);
			J1.setEdadAnimal(3);
			J1.setSexoAnimal("Masculino");
			
			Jirafas J2=new Jirafas(0,0,"");
			J2.setPesoAnimal((float)740);
			J2.setEdadAnimal(4);
			J2.setSexoAnimal("Femenino");
			
			//Pandas
			Pandas Pa1=new Pandas(0,0,"");
			Pa1.setPesoAnimal((float)100);
			Pa1.setEdadAnimal(5);
			Pa1.setSexoAnimal("Femenino");
			
			Pandas Pa2=new Pandas(0,0,"");
			Pa2.setPesoAnimal((float)123);
			Pa2.setEdadAnimal(6);
			Pa2.setSexoAnimal("Masculino");
			
			//Lemures
			Lemures Le1=new Lemures(0,0,"");
			Le1.setPesoAnimal((float)4.3);
			Le1.setEdadAnimal(1);
			Le1.setSexoAnimal("Masculino");
			
			Lemures Le2=new Lemures(0,0,"");
			Le2.setPesoAnimal((float)3);
			Le2.setEdadAnimal(2);
			Le2.setSexoAnimal("Masculino");
			
			Lemures Le3=new Lemures(0,0,"");
			Le3.setPesoAnimal((float)2.5);
			Le3.setEdadAnimal(3);
			Le3.setSexoAnimal("Masculino");
			
			LeonB.add(0, L1);
			LeonB.add(1,L2);
			LeonB.add(2,L3);
			LeonB.add(3,L4);	
		
			
			PinguiB.add(0,P1);
			PinguiB.add(1,P2);
			PinguiB.add(2,P3);
			PinguiB.add(3,P4);
			
			
			JiraB.add(0,J1);
			JiraB.add(1,J2);
			
			
			PandaB.add(0, Pa1);
			PandaB.add(1, Pa2);
			
			LemurB.add(0, Le1);
			LemurB.add(1, Le2);
			LemurB.add(2, Le3);
						
 		
 	}
 	
 	//Acciones a realizar al pulsar los botones de opcion
	public void actionPerformed(ActionEvent e) {
		// TODO Auto-generated method stub
		
		//Boton para agregar animales
		if(e.getSource()==op1) {
			//Se colocan los botones invisibles para la vista del menu secundario
			this.op1.setVisible(false);	this.op2.setVisible(false);	this.op3.setVisible(false);	this.op4.setVisible(false);
			this.La1.setVisible(false); this.J.setVisible(false); 
			//Opciones
			this.La2=new JLabel("Seleccione el tipo de animal:");this.La2.setBounds(370, 100, 300, 50);
			this.vent.add(La2);	this.La2.setVisible(true); this.vent.setVisible(true);
			
			//Boton Leon
			this.Leon.setVisible(true);this.vent.add(Leon); this.Leon.setBounds(300, 200, 300, 50);
			this.Leon.addActionListener(new ActionListener() {
				public void actionPerformed(ActionEvent e) {
					Ventana2 sv=new Ventana2(LeonA);
					sv.panel.add(back);
					ventana.setContentPane(sv.getJPanel());
					back.setVisible(true);
				}
		});
			//Boton Pinguino
			this.Pinguin.setVisible(true);this.vent.add(Pinguin); this.Pinguin.setBounds(300, 250, 300, 50);
			this.Pinguin.addActionListener(new ActionListener() {
				public void actionPerformed(ActionEvent e) {
					Ventana3 sv=new Ventana3(PinguiA);
					sv.panel.add(back);
					ventana.setContentPane(sv.getJPanel());
					back.setVisible(true);
				}
		});
			//Boton Jirafa
			this.Jiraf.setVisible(true);this.vent.add(Jiraf); this.Jiraf.setBounds(300, 300, 300, 50);
			this.Jiraf.addActionListener(new ActionListener() {
				public void actionPerformed(ActionEvent e) {
					Ventana4 sv=new Ventana4(JiraA);
					sv.panel.add(back);
					ventana.setContentPane(sv.getJPanel());
					back.setVisible(true);
				}
		});
			//Boton Lemur
			this.Lemu.setVisible(true);this.vent.add(Lemu); this.Lemu.setBounds(300, 350, 300, 50);
			this.Lemu.addActionListener(new ActionListener() {
				public void actionPerformed(ActionEvent e) {
					Ventana5 sv=new Ventana5(LemurA);
					sv.panel.add(back);
					ventana.setContentPane(sv.getJPanel());
					back.setVisible(true);
				}
		});
			//Boton panda
			this.Pand.setVisible(true);this.vent.add(Pand); this.Pand.setBounds(300, 400, 300, 50);
			this.Pand.addActionListener(new ActionListener() {
				public void actionPerformed(ActionEvent e) {
					Ventana6 sv=new Ventana6(PandaA);
					sv.panel.add(back);
					ventana.setContentPane(sv.getJPanel());
					back.setVisible(true);
				}
		});
			
		}
		
		//Boton de mostrar animales
		if(e.getSource()==op2) {
			
			this.op1.setVisible(false);	this.op2.setVisible(false);	this.op3.setVisible(false);	this.op4.setVisible(false);
			this.La1.setVisible(false); this.J.setVisible(true);this.SP.setVisible(true);this.back.setVisible(true);
			
			mostrarAnimal(Animales);
		}
		
		//Pago a trabajadores
		if(e.getSource()==op3) {
			cantidad();
			this.ventana.setContentPane(trabajadores);this.trabajadores.setVisible(true);this.vent.setVisible(false);
			this.trabajadores.add(back);this.back.setVisible(true);this.cs.setVisible(true);
			this.vet.setVisible(true);this.vett.setVisible(true);this.cui.setVisible(true);this.cuit.setVisible(true);
			this.anim.setVisible(true);this.ani.setVisible(true);mp.setVisible(false);
			this.cs.addActionListener(new ActionListener() {
				public void actionPerformed(ActionEvent e) {						
					String veta=vett.getText(); String cuia=cuit.getText(); String ana=ani.getText();
					if(isNumeric1(cuia)==true) {
					sueldoc=Float.parseFloat(cuia);
					a1=1;
					}else {
						a1=0;
					}
					if(isNumeric2(veta)==true && isNumeric(ana)==true) {
					sueldov=Float.parseFloat(veta);
					a2=1;
					}else {
						a2=0;
					}
					if( isNumeric(ana)==true) {
						aa=Integer.parseInt(ana);
						a3=1;
					}
					else {
						a3=0;
					}
					if(a1==1 && a2==1 && a3==1) {
						Cuidadores cuidador=new Cuidadores(sueldoc, ta);Veterinarios veterinario=new Veterinarios(sueldov, ta, aa);
						veterinario.pago();cuidador.pago();
						pagoc=Float.toString(cuidador.pago());pagov=Float.toString(veterinario.pago());
		
						mp.setVisible(true);pv.setVisible(true);pv.setText("El sueldo del vet es:"+pagov+"$");
						pc.setVisible(true);pc.setText("El pago del cuidador es"+pagoc+"$");
						cuit.setText(null);vett.setText(null);ani.setText(null);
					}
					if (a1==0 || a2==0 || a3==0){
							cuit.setText(null);vett.setText(null);ani.setText(null);
					}
					
				}
			});
		}
		
		//Boton salir
		if(e.getSource()==op4) {
			ventana.dispose();
		}
		
		//Boton volver al menu principal
		if(e.getSource()==back) {
			this.ventana.setContentPane(vent);this.vent.setVisible(true);this.vent.add(back);
			this.back.setVisible(true);
			this.Pinguin.setVisible(false);	this.Pand.setVisible(false);this.Leon.setVisible(false);this.Jiraf.setVisible(false);this.Lemu.setVisible(false);
			this.op1.setVisible(true);	this.op2.setVisible(true);	this.op3.setVisible(true);	this.op4.setVisible(true);
			this.La1.setVisible(true); this.J.setVisible(false);this.SP.setVisible(false);this.La2.setVisible(false);
			this.vet.setVisible(false);this.cui.setVisible(false); this.vett.setVisible(false);this.cuit.setVisible(false);
			this.ani.setVisible(false);this.anim.setVisible(false); this.cs.setVisible(false); this.mp.setVisible(false);
		}
		
	}

	//Metodo para mostrar animales
	public void mostrarAnimal(ArrayList Animal){
		
		String texto="";
		for(int i=0; i<LeonB.size();i++) {
			texto+=LeonB.get(i)+"\n";
		}
		J.setText(texto);
		for(int i=0; i<JiraB.size();i++) {
			texto+=JiraB.get(i)+"\n";
		}
		J.setText(texto);
		for(int i=0; i<LemurB.size();i++) {
		texto+=LemurB.get(i)+"\n";
		}
		J.setText(texto);
		for(int i=0; i<PandaB.size();i++) {
			texto+=PandaB.get(i)+"\n";
		}
		J.setText(texto);
		for(int i=0; i<PinguiB.size();i++) {
			texto+=PinguiB.get(i)+"\n";
		}
		J.setText(texto);
		for(int i=0; i<LeonA.size();i++) {
			texto+=LeonA.get(i)+"\n";
		}
		J.setText(texto);
		for(int i=0; i<PinguiA.size();i++) {
			texto+=PinguiA.get(i)+"\n";
		}
		J.setText(texto);
		for(int i=0; i<JiraA.size();i++) {
			texto+=JiraA.get(i)+"\n";
		}
		J.setText(texto);
		for(int i=0; i<LemurA.size();i++) {
			texto+=LemurA.get(i)+"\n";
		}
		J.setText(texto);
		for(int i=0; i<PandaA.size();i++) {
			texto+=PandaA.get(i)+"\n";
		}
		J.setText(texto);
	}
	
	//Metodo para calcular la cantidad de animales en el zoo
	public void cantidad() {
		ta=LeonB.size()+LeonA.size()+JiraB.size()+JiraA.size()+LemurB.size()+LemurA.size()+PinguiB.size()+PinguiA.size()+PandaB.size()+PandaA.size();
	}

	//verficacion de datos int y float con un metodo
		 public static boolean isNumeric(String ana) {

		        boolean resultado;

		        try {
		            Integer.parseInt(ana);
		            resultado = true;
		        } catch (NumberFormatException excepcion) {
		            resultado = false;
		        }

		        return resultado;
		    }

		 public static boolean isNumeric1(String cuia) {

		        boolean resultado;

		        try {
		           Float.parseFloat(cuia);
		            resultado = true;
		        } catch (NumberFormatException excepcion) {
		            resultado = false;
		        }

		        return resultado;
		    }
		 public static boolean isNumeric2(String veta) {

		        boolean resultado;

		        try {
		           Float.parseFloat(veta);
		            resultado = true;
		        } catch (NumberFormatException excepcion) {
		            resultado = false;
		        }

		        return resultado;
		    }
}
