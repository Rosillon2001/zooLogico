package appZoo;

public class Animal {
	
	private float PesoAnimal;
	private int EdadAnimal;
	private String SexoAnimal;
	
	public Animal(float PesoAnimal, int EdadAnimal, String SexoAnimal) {
		this.EdadAnimal=EdadAnimal;
		this.PesoAnimal=PesoAnimal;
		this.SexoAnimal=SexoAnimal;
	}
	

	//Getters and setters
	public float getPesoAnimal() {
		return PesoAnimal;
	}
	public void setPesoAnimal(float pesoAnimal) {
		this.PesoAnimal = pesoAnimal;
	}

	public int getEdadAnimal() {
		return EdadAnimal;
	}

	public void setEdadAnimal(int edadAnimal) {
		EdadAnimal = edadAnimal;
	}

	public String getSexoAnimal() {
		return SexoAnimal;
	}

	public void setSexoAnimal(String sexoAnimal) {
		SexoAnimal = sexoAnimal;
	}
	


}
