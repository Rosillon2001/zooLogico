package Servidor;

public class AppS {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		ServerApp sa=new ServerApp();
		sa.start();
	}
}
