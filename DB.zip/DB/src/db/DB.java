package db;
import java.awt.Component;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;

import javax.swing.JFrame;
import javax.swing.JOptionPane;


public class DB {
private static DB DB= new DB();
private Connection conn;
private Statement stmt;
private PreparedStatement pstmt;
private ResultSet rs;
private String driverDB="org.postgresql.Driver";
private String dbName= "appZoo";
private String urlDB="jdbc:postgresql://localhost:5432/appZoo";
private String userDB="postgres";
private String passDB="admin";
public String AA="";

//conexion con la base de datos
private DB () {
	try {
		Class.forName(driverDB);
		this.conn=DriverManager.getConnection(urlDB,userDB,passDB);
		JFrame ventana = null;
		JOptionPane.showMessageDialog(ventana, "Conexion establecida con la Base de Datos\nPulse aceptar para acceder al menu\n O en su defecto cierre esta ventana");
	}catch(ClassNotFoundException | SQLException e){
		e.printStackTrace();
	}
}

//metodo singleton (instancia unica)
public static DB getInstances() {
	return DB;
}

//metodo para borrar un animal segun su id
	public void borrar(int I) {
	try {
		this.stmt=this.conn.createStatement();
		this.rs=this.stmt.executeQuery("DELETE FROM Animal Where idanimal="+I);
	}	catch(SQLException e) {
		e.printStackTrace();
	}finally {
		try {
			this.stmt.close();
			this.rs.close();
		}catch(SQLException e){
			e.printStackTrace();
		}
	}
	return;
}
	//metodo que retorna la cantidad de animales existentes en la base de datos
	public int cantidad() {
		int canti = 0;
		ArrayList <String>cant=new ArrayList<String>();
		try {
			this.stmt=this.conn.createStatement();
			this.rs=this.stmt.executeQuery("SELECT *FROM Animal");
			String AA="";
			while(rs.next()) {
				int aa=rs.getInt("idanimal");
				AA=Integer.toString(aa);
				cant.add(AA);
				canti=cant.size();
			}
		}catch(SQLException e) {
			e.printStackTrace();
		}finally {
			try {
				this.stmt.close();
				this.rs.close();
			}catch(SQLException e){
				e.printStackTrace();
			}
		}
		return canti;
	}
	
	//metodo para guardar los datos de un animal
	public String[] guardar(int Id) {
		String an[]=new String[5]; 
		try {
			this.pstmt=this.conn.prepareStatement("SELECT *FROM Animal WHERE idanimal=?");
			this.pstmt.setInt(1, Id);
			this.rs=this.pstmt.executeQuery();
			if(rs.next()){
				int ana=rs.getInt("idanimal");
				an[0]=Integer.toString(ana);
				float ana2=rs.getFloat("pesoanimal");
				an[1]=Float.toString(ana2);
				int ana1=rs.getInt("edadanimal");
				an[2]=Integer.toString(ana1);
				an[3]=rs.getString(4);
				an[4]=rs.getString(5);
			}
			else {
			}
		}catch(Exception e){
			System.out.println(e.getMessage());
		}
		return an;
	}
	
	//metodo para modificar los datos de un animal
	public void modificar( String an[]) {
		try {
			this.pstmt=conn.prepareStatement("UPDATE Animal SET pesoanimal=?,edadanimal=?, sexoanimal=?, tipoanimal=? Where idanimal="+an[0]);
			this.pstmt.setFloat(1, Float.parseFloat(an[1]));
			this.pstmt.setInt(2, Integer.parseInt(an[2]));
			this.pstmt.setString(3, an[3]);
			this.pstmt.setString(4, an[4]);
			this.pstmt.executeUpdate();
		}	catch(SQLException e) {
			e.printStackTrace();
		}finally {
			try {
				this.stmt.close();
				this.rs.close();
			}catch(SQLException e){
				e.printStackTrace();
			}
		}

	}
		

	//metodo para mostrar todos los animales que hay en la db
	public String mostrar () {
		try {
			this.stmt=this.conn.createStatement();
			this.rs=this.stmt.executeQuery("SELECT *FROM Animal ORDER BY idanimal ASC");
			AA="";
			while(rs.next()) {
				AA+="Id del Animal:"+rs.getInt("idanimal")+"\t"+"Peso del Animal:"+rs.getFloat("pesoanimal")+"kg\t"+"Edad del Animal:"+rs.getInt("edadanimal")+"anios\t"+"Sexo:"+rs.getString("SexoAnimal")+"\t"+"Especie:"+rs.getString("tipoanimal")+"\n"+"\n";
			}
		}catch(SQLException e) {
			e.printStackTrace();
		}finally {
			try {
				this.stmt.close();
				this.rs.close();
			}catch(SQLException e){
				e.printStackTrace();
			}
		}
		return AA;
	}

	//metodo para la asignacion de ids
	public int Id(){
		
		int id=1;
		try {
			this.stmt=this.conn.createStatement();
			this.rs=this.stmt.executeQuery("SELECT MAX(idanimal) FROM Animal");
			while(rs.next()) {
				id=rs.getInt(1)+1;
			}
			}catch(Exception e) {
			System.out.println("Error"+e.getMessage());	
			}finally {
				try {
					this.stmt.close();
					this.rs.close();
				}catch(Exception o){	
				}
			}
		return id;
	}

	//cerrar conexion con la base de datos
	public void dbClose() {
		try {
			this.conn.close();
			JFrame ventana = null;
			JOptionPane.showMessageDialog(ventana, "Conexion finalizada");
		}catch(SQLException e) {
			e.printStackTrace();
		}
	}
	
	public void AgregarAnimal(String query, Object[] o) {
		try {
			this.pstmt=this.conn.prepareStatement(query);
			this.pstmt.setInt(1, (int)o[0]);
			this.pstmt.setFloat(2, (float)o[1]);
			this.pstmt.setInt(3, (int)o[2]);
			this.pstmt.setString(4, (String)o[3]);
			this.pstmt.setString(5, (String)o[4]);
			this.pstmt.executeUpdate();
		}catch(SQLException e) {
			e.printStackTrace();
		} finally {
			try {
	this.pstmt.close();
			}catch(SQLException e) {
				e.printStackTrace();
			}
		}
	}
}
