package appZoo;

import intGraf.UserInterface;

public class Main {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		UserInterface intGraf = new UserInterface();

	}

}