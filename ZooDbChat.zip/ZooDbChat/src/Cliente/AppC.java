package Cliente;

public class AppC {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		ClientApp c=new ClientApp();
	}

}
