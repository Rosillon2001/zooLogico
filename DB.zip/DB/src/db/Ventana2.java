package db;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.ArrayList;
import javax.swing.*;


//ventana para el ingreso de leones al sistema
public class Ventana2{
	public int a;
	//Atributos
	
		public JPanel panel;
		private JLabel label;
		private JLabel label1;
		private JLabel label2;
		private JTextField txt;
		private JTextField txt1;
		private JTextField txt2;
		private JButton add;
		private JLabel error;
		private JFrame er;
		private JLabel ex;
		float pe;
		int ed;
		String s; String pesoa; String edada;String sexoa;
		String L="Leon";
		int a1;
		int a2;
		int a3;
		

		//Constructor
DB db=DB.getInstances();
		public Ventana2(int a) {
			// TODO Auto-generated constructor stub
			this.er=new JFrame();this.er.setBounds(300,200,300,200);this.er.setLayout(null);
			this.ex=new JLabel("Animal aniadido exitosamente");this.ex.setBounds(0,0, 250, 50);this.er.add(ex);
			panel = new JPanel();panel.setBounds(0, 0, 950, 600);
			this.label=new JLabel("Peso del leon:");this.label.setBounds(200, 100, 300, 50);this.panel.add(label);
			this.label1=new JLabel("Edad del Leon:");this.label1.setBounds(200, 200, 300, 50);this.panel.add(label1);
			this.label2=new JLabel("Sexo del Leon (Femenino o Masculino):");this.label2.setBounds(150, 300, 300, 50);this.panel.add(label2);
			this.txt=new JTextField();this.txt.setBounds(400, 100, 300, 50);this.panel.add(txt);
			this.txt1=new JTextField();this.txt1.setBounds(400, 200, 300, 50);this.panel.add(txt1);
			this.txt2=new JTextField();this.txt2.setBounds(400, 300, 300, 50);this.panel.add(txt2);
			this.error=new JLabel("Error");this.error.setBounds(0, 0, 100, 50);this.er.add(error);
			this.add=new JButton("Aniadir"); this.add.setBounds(450, 400, 100, 50);this.panel.add(add);
			this.add.addActionListener(new ActionListener () {
				public void actionPerformed(ActionEvent e) {
					
					String p=txt.getText();String a=txt1.getText();	String s=txt2.getText();
					
					if(s.equalsIgnoreCase("Femenino")||s.equalsIgnoreCase("Masculino")) {
						sexoa=s;
						a1=1;
					}
					else {
						a1=0;
					};
										
					if(isNumeric1(p)==true) {
						pe=Float.parseFloat(p);
						a3=1;
						
					}
					else {
						a3=0;
					}
					if(isNumeric(a)==true) {
						ed=Integer.parseInt(a);
						
						a2=1;
					}
					else {
						a2=0;
					}
					if(a1==1 && a2==1 && a3==1) {
						int edada=db.Id();
						er.setVisible(true);ex.setVisible(true);error.setVisible(false);
						txt.setText(null);txt1.setText(null);txt2.setText(null);
						
						Object []o= {edada,pe,ed,sexoa,L};
						db.AgregarAnimal("insert into Animal(idAnimal, PesoAnimal,EdadAnimal,SexoAnimal,TipoAnimal) values (?,?,?,?,?)", o);
					}
					else {
						er.setVisible(true);ex.setVisible(false);error.setVisible(true);
						txt.setText(null);txt1.setText(null);txt2.setText(null);
					}
					
				
				}
			});
			
			
						
			this.panel.setLayout(null);
		}
		
		public JPanel getJPanel() {
			return this.panel;
			
		}
	
		 //verficacion de datos int y float con un metodo
		 public static boolean isNumeric(String a) {

		        boolean resultado;

		        try {
		            Integer.parseInt(a);
		            resultado = true;
		        } catch (NumberFormatException excepcion) {
		            resultado = false;
		        }

		        return resultado;
		    }

		 public static boolean isNumeric1(String p) {

		        boolean resultado;

		        try {
		           Float.parseFloat(p);
		            resultado = true;
		        } catch (NumberFormatException excepcion) {
		            resultado = false;
		        }

		        return resultado;
		    }

		 
		
	}

