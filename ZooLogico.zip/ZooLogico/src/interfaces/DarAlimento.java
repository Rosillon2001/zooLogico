package interfaces;

public interface DarAlimento {
	
	public void comer();

}
