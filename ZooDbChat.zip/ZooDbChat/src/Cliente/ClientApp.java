package Cliente;

import java.awt.Color;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.BufferedReader;
import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.net.Socket;

import javax.swing.BorderFactory;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTextArea;
import javax.swing.JTextField;
import javax.swing.ScrollPaneConstants;

import java.io.BufferedReader;
import java.io.DataOutputStream;
import java.io.IOException;
import java.io.InputStreamReader;
import java.net.Socket;

public class ClientApp {
	
	private JFrame v;
	private JPanel p;
	private JTextField t;
	private JTextArea a;
	private JButton enviar;
	private JScrollPane SP;
	private JLabel option;
	private JLabel chat1;

	
	private Socket socket=null;
	private DataOutputStream out=null;
	private DataInputStream in;
	
	
	public ClientApp (){
		this.v=new JFrame("ZooLogico client");this.v.setVisible(true);this.v.setBounds(200, 200, 500, 500);this.v.setLayout(null);this.v.setResizable(false);
		this.p=new JPanel();this.v.add(p);this.p.setVisible(true);this.p.setBounds(0, 0, 500, 500);this.p.setLayout(null);
		this.t=new JTextField();this.p.add(t);this.t.setVisible(true);this.t.setBounds(0, 420, 400, 50);this.t.setBorder(BorderFactory.createLineBorder(Color.GREEN,1));
		this.a=new JTextArea();this.p.add(a);this.a.setVisible(true);this.a.setBounds(0, 100, 500, 200);this.a.setBorder(BorderFactory.createLineBorder(Color.GREEN,1));
		this.option=new JLabel("Escriba: 'ayuda' en el area de texto para mostrar los comandos");this.p.add(option);this.option.setBounds(60,0, 400, 100);
		this.chat1=new JLabel("Ingrese un comando:");this.p.add(chat1);this.chat1.setVisible(true);this.chat1.setBounds(10, 380, 150, 50);
		
		this.SP=new JScrollPane(a); this.p.add(SP);this.SP.setVerticalScrollBarPolicy(ScrollPaneConstants.VERTICAL_SCROLLBAR_ALWAYS);
		this.SP.setBounds(0, 100, 490, 200); this.SP.setVisible(true);
		this.enviar=new JButton("Enviar");this.p.add(enviar);this.enviar.setBounds(400, 420, 100, 50);this.enviar.setVisible(true);this.enviar.setBorder(BorderFactory.createLineBorder(Color.GREEN,1));
		
		//action performed para enviar los comandos hacia la app servidor
		this.enviar.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				try {
					socket=new Socket("localhost", 8080);
					out=new DataOutputStream(socket.getOutputStream());					
					String line=t.getText();
					out.writeUTF(line);
					//recibe los datos seg[un el comando enviado
					in=new DataInputStream(socket.getInputStream());
					String txt=in.readUTF();
					a.setText(txt);
					out.close();
					in.close();
				}catch(IOException err) {
					JOptionPane.showMessageDialog(v, "Comando erroneo, escriba 'ayuda' para ver los comandos");
					t.setText(null);
				}
				finally {
					try {
						socket.close();
					} catch (IOException e1) {
						// TODO Auto-generated catch block
						System.out.println(e1);
					}
				}
			}
		});
	}
}



