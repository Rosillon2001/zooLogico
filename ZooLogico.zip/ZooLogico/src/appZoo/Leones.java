package appZoo;

public class Leones extends Animal {
	


	public Leones(float PesoAnimal, int EdadAnimal, String SexoAnimal) {
		// TODO Auto-generated constructor stub
		super(PesoAnimal, EdadAnimal, SexoAnimal);
	}
	
	@Override
	public String toString() { //metodo toString, para mostrar los datos del objeto 
		StringBuilder sb=new StringBuilder();
		sb.append("\nPeso del Leon:");
		sb.append(getPesoAnimal());
		sb.append("Kg\n");
		sb.append("Edad del Leon:");
		sb.append(getEdadAnimal());
		sb.append("Anios\n");
		sb.append("Sexo del Leon:");
		sb.append(getSexoAnimal()); 
		sb.append("\n");
		return sb.toString();
	}
	public static void add(Leones Li) {
		// TODO Auto-generated method stub
		
	}



	

	





}
